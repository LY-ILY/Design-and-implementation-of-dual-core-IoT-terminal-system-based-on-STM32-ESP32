/*
 * SPDX-FileCopyrightText: 2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 */
#include "nvs_flash.h"
#include "esp_netif.h"
#include "protocol_examples_common.h"
#include "esp_event.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "USART.h"
#include "WIFI.h"
#include "tcp_client_v4.h"
#include "mqtt.h"
#include "task.h"
/*
系统需要完成的功能如下：
1、wifi连接
2、串口接收STM32数据
3、向MQTT发送来自STM32的数据
4、接收来自MQTT的数据
5、使用串口向STM32发送数据
*/

void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    /* This helper function configures Wi-Fi or Ethernet, as selected in menuconfig.
     * Read "Establishing Wi-Fi or Ethernet Connection" section in
     * examples/protocols/README.md for more information about this function.
     */
    
    uart2_init();
    My_wifi_Init();
    //My_wifi_connect();
    //不再使用TCP网络
    /*MQTT初始化*/
    //TCP_Client_Init();
    /*MQTT连接，同时开启事件触发*/
    Mqtt_connect();
    // MQTT客户端配置
    // 使用本地EMQX服务器
    Create_Task(STM32_to_MQTT);
    
    while(1){
        esp_mqtt_client_publish(client, Publish, "Hello! Im ESP32", 0, 1, 0);

       // char data[128];
       // int len = uart_read_bytes(UART2_PORT, data, sizeof(data) - 1, pdMS_TO_TICKS(1000));
       // if (len > 0) {
       //     data[len] = '\0';
        //    printf("Received: %s\n", data);
       // }
       // else{
        //    printf("No Deceived Data!!\n");
       // }
        //printf("hello ESP32!!\n");

        //my_TCP_send_recv(data);
        vTaskDelay(1000 / portTICK_PERIOD_MS);
        }
    TCP_close();
}


/*
void My_LED_Init(void){
    //ESP_ERROR_CHECK(example_connect());
    gpio_config_t pGPIOConfig= {
        .intr_type=GPIO_INTR_DISABLE,//中断类型
        .mode=GPIO_MODE_OUTPUT,//输入输出模式
        .pin_bit_mask=1ULL<<LED_GPIO,//引脚掩码
        .pull_down_en=GPIO_PULLDOWN_DISABLE,//是否使能内部下拉电阻。
        .pull_up_en= GPIO_PULLUP_DISABLE,//是否使能内部上拉电阻。
    };
    
    gpio_config(&pGPIOConfig);
    return;
}
*/
