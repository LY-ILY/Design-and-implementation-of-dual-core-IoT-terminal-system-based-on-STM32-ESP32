#include "task.h"

TaskHandle_t STM32_to_MQTT_handle;
Task_Config STM32_to_MQTT={
  .TaskCode=uart2_receive,
  .name="STM32_to_MQTT",
  .parameter=NULL,
  .priority=5,
  .stack_size=2048,
  .Task_Handle=&STM32_to_MQTT_handle
};

TaskHandle_t MQTT_to_STM32_handle;
Task_Config MQTT_to_STM32={
  .TaskCode=NULL,
  .name="MQTT_to_STM32",
  .parameter=NULL,
  .priority=3,
  .stack_size=4096,
  .Task_Handle=&MQTT_to_STM32_handle
};

// Function that creates a task.
void Create_Task(Task_Config my_tesk)
{
    // Create the task, storing the handle.  Note that the passed parameter ucParameterToPass
    // must exist for the lifetime of the task, so in this case is declared static.  If it was just an
    // an automatic stack variable it might no longer exist, or at least have been corrupted, by the time
    // the new task attempts to access it.
    BaseType_t result =xTaskCreate( my_tesk.TaskCode,
                my_tesk.name,
                my_tesk.stack_size, 
                my_tesk.parameter, 
                my_tesk.priority, 
                my_tesk.Task_Handle);
    
    if (result != pdPASS) {
        ESP_LOGE("TASK", "任务 %s 创建失败！", my_tesk.name);
    }

    // Use the handle to delete the task.
    /*
     if( my_tesk.Task_Handle != NULL )
    {
        vTaskDelete( my_tesk.Task_Handle );
    }
    */
   
}

