#include "mqtt.h"

esp_mqtt_client_handle_t client = NULL;
static const char *TAG = "MQTT_EXAMPLE";
//static esp_mqtt_client_handle_t client;

// MQTT事件处理函数
void mqtt_event_handler(void *handler_args, esp_event_base_t base,
                               int32_t event_id, void *event_data) {
    esp_mqtt_event_handle_t event = event_data;
    client = event->client;

    switch (event->event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "MQTT_EVENT_CONNECTED");
            esp_mqtt_client_subscribe(client, Subscribe, 0);
            ESP_LOGI(TAG, "MQTT_EVENT_Subscribe");
            esp_mqtt_client_publish(client, Publish, "Hello from ESP32-S3", 0, 0, 0);
            ESP_LOGI(TAG, "MQTT_EVENT_Publish");
            break;

        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGI(TAG, "MQTT_EVENT_DISCONNECTED");
            break;

        case MQTT_EVENT_DATA:
            ESP_LOGI(TAG, "MQTT_EVENT_DATA");
            printf("TOPIC=%.*s\r\n", event->topic_len, event->topic);
            printf("DATA=%.*s\r\n", event->data_len, event->data);
            //调用串口，实现数据传递给STM32
            //应该创建一个堆变量，控制具体长度，这样log时才不会有多余内容
            uart2_send(event->data,event->data_len);
            break;

        default:
            break;
    }
}

void Mqtt_connect(){

    esp_mqtt_client_config_t mqtt_cfg = {
        .broker = {
            .address.uri = MQTT_URI, // 替换为电脑IP
            //.verification.skip_cert_common_name_check = true,
        },
        .credentials = {
            .username = MQTT_user_Name,  // EMQX默认用户名
            .authentication.password = MQTT_password, // EMQX默认密码
        }
    };
    // 创建MQTT客户端
    client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    esp_mqtt_client_start(client);
}
void MQTT_publish(char *messgage){
    esp_mqtt_client_publish(client, Publish, (char*)messgage, 0, 1, 0);
}
