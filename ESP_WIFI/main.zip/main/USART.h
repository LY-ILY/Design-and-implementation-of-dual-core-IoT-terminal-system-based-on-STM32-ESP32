#ifndef __USART_H__
#define __USART_H__
#include "soc/uart_channel.h"
#include <stdio.h>
#include "driver/uart.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include <string.h>
#include "mqtt.h"

// UART2 配置参数
#define UART2_TX_PIN GPIO_NUM_17   // UART2 发送引脚
#define UART2_RX_PIN GPIO_NUM_18   // UART2 接收引脚
#define UART2_PORT   UART_NUM_2    // UART2 端口号
#define BUF_SIZE     512          // 缓冲区大小

void uart2_init(void);
void uart2_send(const char* data,uint16_t len);
void uart2_receive(void* pra);

#endif