#include "USART.h"

static const char *USART_TAG = "UART2_EXAMPLE";

// 初始化 UART2
void uart2_init(void) {
    // UART 配置结构体
    uart_config_t uart_config = {
        .baud_rate = 115200,          // 波特率
        .data_bits = UART_DATA_8_BITS, // 数据位
        .parity = UART_PARITY_DISABLE, // 无校验
        .stop_bits = UART_STOP_BITS_1, // 停止位
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE, // 无流控
        .source_clk = UART_SCLK_APB,  // 时钟源
    };
    
    // 配置 UART2 参数
    ESP_ERROR_CHECK(uart_param_config(UART2_PORT, &uart_config));
    
    // 设置 UART2 引脚
    ESP_ERROR_CHECK(uart_set_pin(UART2_PORT, UART2_TX_PIN, UART2_RX_PIN, 
                                UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    
    // 安装 UART 驱动程序
    ESP_ERROR_CHECK(uart_driver_install(UART2_PORT, BUF_SIZE * 2, 
                                       BUF_SIZE * 2, 0, NULL, 0));
    
    ESP_LOGI(USART_TAG, "UART2 Init completed (TX:GPIO%d, RX:GPIO%d)", UART2_TX_PIN, UART2_RX_PIN);
}

// UART2 发送数据
void uart2_send(const char* data,uint16_t len) {
    //const int len = strlen(data);
    const int txBytes = uart_write_bytes(UART2_PORT, data, len);
    ESP_LOGI(USART_TAG, "UART send %d Byte: %s", txBytes, data);
}

// UART2 接收数据
void uart2_receive(void* pra) {
    uint8_t data[BUF_SIZE];
    vTaskDelay(10000 / portTICK_PERIOD_MS);
    while (1) {
        // 等待数据
        
        const int rxBytes = uart_read_bytes(UART2_PORT, data, BUF_SIZE - 1, pdMS_TO_TICKS(1000));
        
        if (rxBytes > 0) {
            data[rxBytes] = '\0'; // 添加终止符
            ESP_LOGI(USART_TAG, "UART Receive %d Byte: %s", rxBytes, (char*)data);
            MQTT_publish((char*)data);
            // 回显接收到的数据
            //uart_write_bytes(UART2_PORT, (const char*)data, rxBytes);
            printf("%s\n",(char*)data);
        } else if (rxBytes == 0) {
            ESP_LOGD(USART_TAG, "NOT Receive data");
        } else {
            ESP_LOGE(USART_TAG, "Receive Error: %d", rxBytes);
        }
        //vTaskDelay(pdMS_TO_TICKS(100));  // 增加这一行
    }
}



