#ifndef __MY__TOPIC__H__
#define __MY__TOPIC__H__
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
uint8_t topic_to_topicid(char *topic);
uint8_t string_to_uint8(const char* str) ;
#endif
